#! /bin/bash
cd ~/kafka/kafka_2.12-2.3.0/
bin/kafka-server-start.sh config/server.properties