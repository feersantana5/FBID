#! /bin/bash
echo 'Abrimos la aplicación'
intellij-idea-community
echo 'Configurar los ajustes del IDE, compilar y ejecutar el proyecto'
